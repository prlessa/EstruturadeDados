#include <stdio.h>
#include <stdlib.h>
using namespace std;

int digito (char c) {
  if ((c>='0') && (c<='9')) 
    return 1; 
  else 
    return 0; 
} 

char maiuscula (char c) { 
  if (c>='a' && c<='z')
    c = c - 'a' + 'A'; 
  return c;
}

int comprimento (char* s) { 
  int i;
  int n=0;
  for (i=0; s[i] != '\0'; i++)
    n++; 
  return n;
}

void copia (char* destino, char* origem) { 
  int i;
  for (i=0; origem[i] != '\0'; i++) 
    destino[i] = origem[i];
  destino[i] = '\0'; 
}

void concatena (char* dest, char* orig) {
  int i = 0; // indice destino
  int j; // indice origem
  while (dest[i] != '\0') // acha o fnal da cadeia destino
    i++;
  for (j=0; orig[j] != '\0'; j++) {
    dest[i] = orig[j];
    i++; 
  }
  dest[i] = '\0'; 
}

int compara (char* s1, char* s2) { 
  int i;
  for (i=0; s1[i] != '\0' && s2[i] != '\0'; i++) { 
    if (s1[i] < s2[i])
      return -1;
    else if (s1[i] > s2[i])
      return 1; 
  }
  if (s1[i] == s2[i]) //strings iguais 
    return 0;
  else if (s2[i] != '\0') //s1 é menor, pois tem menos caracteres 
    return -1;
  else
    return 1; // s2 é menor, pois tem menos caracteres
}

void imprime (int n, char var[81]) { 
  for (int i=0; i<n; i++)
    printf("%c", var[i]);
}

int main(void){
    /*char c = 'a';
    printf ("%d %c\n", c, c); 

    printf ("%i\n", digito('2'));

    printf ("%c\n", maiuscula('a'));


    char str[4];
    str[0] = 'O';
    str[1] = 'l';
    str[2] = 'a';
    str[3] = '\0';
    printf ("%s \n", str);

    char str2 [] = "Ola";
    printf ("%s \n", str);

    char str3 [] = {'O', 'l', 'a', '\0'};
    printf ("%s \n", str);*/

    //char cidade [] = "rio";
    //printf ("%s \n", cidade);

    /*for (int i=0;i<4;i++)
      printf ("%c", maiuscula(cidade[i]));

    printf("\n");

    printf ("%i\n", comprimento(cidade));*/

    char cidade [] = "rio";
    printf ("\ncidade: %s \n", cidade);

    char dest [81];
    copia(dest, cidade);
    printf ("copiar: %s\n", dest);

    char city [] = " de janeiro";
    concatena(dest, city);
    printf ("concatenar: %s\n", dest);

    /*printf ("%i\n", compara(destino, cidade));

    imprime(comprimento(cidade), cidade);*/
  
    printf ("\n");

    /*char a;
    scanf (" %c", &a);
    printf ("%c \n", a);

    /*char city[81];
    scanf ("%s", city);
    printf ("%s \n", city);

    
    scanf (" %s", city);
    printf ("%s \n", city);*/

    /*char city[4];
    scanf (" %[^\n]", city);
    printf ("%s \n", city);*/


}




